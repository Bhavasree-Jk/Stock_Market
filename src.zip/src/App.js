import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

import Home from './components/Home';
import RegistrationPage from './components/RegistrationPage';
import LoginPage from './components/LoginPage';
import Portfolio from './components/Portfolio';
import CompaniesCatlog from './components/CompaniesCatlog';
import DematAccount from './components/DematAccount';
import CreateDemat from './components/CreateDemat';
import Learn from './components/Learn';
import Budget from './components/Budget';

const App = () => {
  return (
    <Router>
      <div>
        {/* Simple Navigation Bar */}
        <nav style={{ padding: '10px', background: '#f0f0f0' }}>
          <Link to="/" style={{ margin: '0 10px' }}>Home</Link>
          <Link to="/portfolio" style={{ margin: '0 10px' }}>Portfolio</Link>
          <Link to="/budget" style={{ margin: '0 10px' }}>Budget</Link>
          <Link to="/catlog" style={{ margin: '0 10px' }}>Companies</Link>
          <Link to="/demataccount" style={{ margin: '0 10px' }}>Demat Account</Link>
          <Link to="/createdemat" style={{ margin: '0 10px' }}>Create Demat</Link>
          <Link to="/learn" style={{ margin: '0 10px' }}>Learn</Link>
          <Link to="/register" style={{ margin: '0 10px' }}>Register</Link>
          <Link to="/login" style={{ margin: '0 10px' }}>Login</Link>
        </nav>

        {/* Page Routes */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/register" element={<RegistrationPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/catlog" element={<CompaniesCatlog />} />
          <Route path="/demataccount" element={<DematAccount />} />
          <Route path="/createdemat" element={<CreateDemat />} />
          <Route path="/learn" element={<Learn />} />
          <Route path="/budget" element={<Budget />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
